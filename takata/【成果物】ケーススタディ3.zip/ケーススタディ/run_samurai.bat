@echo off
python samurai.py > app.log